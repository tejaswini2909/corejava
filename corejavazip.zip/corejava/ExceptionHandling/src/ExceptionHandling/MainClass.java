package ExceptionHandling;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		try {
			Scanner a=new Scanner(System.in);
		System.out.print("Enter first number");
		int n1=a.nextInt();
		System.out.print("Enter second number");
		int n2=a.nextInt();	
		System.out.println(n1/n2);
		System.out.println("Arithmetic Task complete here");
		}catch(InputMismatchException e) {
			e.printStackTrace();
			System.out.println("Enter only integer");
		}
		catch(ArithmeticException e) {
			e.printStackTrace();
			System.out.println("Enter second number other than zero");
		}
		catch(Exception e) {
			e.printStackTrace();
	}
			System.out.println("Code after try and catch block");
	}
}	
