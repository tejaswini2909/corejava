package com.cg.banking.daoservices;
import com.cg.banking.beans.Customer;
public class BankingDAOServicesImpl implements BankingDAOServices{
	private static Customer[] customerList=new Customer[10];
	private static int CUSTOMER_ID_COUNTER=111;
	private static int CUSTOMER_IDX_COUNTER=0;
	
	public int insertCustomer(Customer customer) {
		
	}

}




