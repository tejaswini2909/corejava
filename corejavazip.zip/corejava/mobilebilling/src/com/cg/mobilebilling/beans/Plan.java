package com.cg.mobilebilling.beans;
public class Plan {
			private int planID,monthlyRental,freeLocalcalls,freeStdCalls,freeLocalSMS,
								freestdSMS,freeInternetDataUsageUnits,localCallRate,localSMSRate,
								stdCallRate,stdSMSRate,internetDataUsageRate;
			 private String planCircle,planName;
			 
			 public Plan() {
			}

			public Plan(int planID, int monthlyRental, int freeLocalcalls, int freeStdCalls, int freeLocalSMS,
					int freestdSMS, int freeInternetDataUsageUnits, int localCallRate, int localSMSRate,
					int stdCallRate, int stdSMSRate, int internetDataUsageRate, String planCircle, String planName) {
				super();
				this.planID = planID;
				this.monthlyRental = monthlyRental;
				this.freeLocalcalls = freeLocalcalls;
				this.freeStdCalls = freeStdCalls;
				this.freeLocalSMS = freeLocalSMS;
				this.freestdSMS = freestdSMS;
				this.freeInternetDataUsageUnits = freeInternetDataUsageUnits;
				this.localCallRate = localCallRate;
				this.localSMSRate = localSMSRate;
				this.stdCallRate = stdCallRate;
				this.stdSMSRate = stdSMSRate;
				this.internetDataUsageRate = internetDataUsageRate;
				this.planCircle = planCircle;
				this.planName = planName;
			}

			public int getPlanID() {
				return planID;
			}

			public void setPlanID(int planID) {
				this.planID = planID;
			}

			public int getMonthlyRental() {
				return monthlyRental;
			}

			public void setMonthlyRental(int monthlyRental) {
				this.monthlyRental = monthlyRental;
			}

			public int getFreeLocalcalls() {
				return freeLocalcalls;
			}

			public void setFreeLocalcalls(int freeLocalcalls) {
				this.freeLocalcalls = freeLocalcalls;
			}

			public int getFreeStdCalls() {
				return freeStdCalls;
			}

			public void setFreeStdCalls(int freeStdCalls) {
				this.freeStdCalls = freeStdCalls;
			}

			public int getFreeLocalSMS() {
				return freeLocalSMS;
			}

			public void setFreeLocalSMS(int freeLocalSMS) {
				this.freeLocalSMS = freeLocalSMS;
			}

			public int getFreestdSMS() {
				return freestdSMS;
			}

			public void setFreestdSMS(int freestdSMS) {
				this.freestdSMS = freestdSMS;
			}

			public int getFreeInternetDataUsageUnits() {
				return freeInternetDataUsageUnits;
			}

			public void setFreeInternetDataUsageUnits(int freeInternetDataUsageUnits) {
				this.freeInternetDataUsageUnits = freeInternetDataUsageUnits;
			}

			public int getLocalCallRate() {
				return localCallRate;
			}

			public void setLocalCallRate(int localCallRate) {
				this.localCallRate = localCallRate;
			}

			public int getLocalSMSRate() {
				return localSMSRate;
			}

			public void setLocalSMSRate(int localSMSRate) {
				this.localSMSRate = localSMSRate;
			}

			public int getStdCallRate() {
				return stdCallRate;
			}

			public void setStdCallRate(int stdCallRate) {
				this.stdCallRate = stdCallRate;
			}

			public int getStdSMSRate() {
				return stdSMSRate;
			}

			public void setStdSMSRate(int stdSMSRate) {
				this.stdSMSRate = stdSMSRate;
			}

			public int getInternetDataUsageRate() {
				return internetDataUsageRate;
			}

			public void setInternetDataUsageRate(int internetDataUsageRate) {
				this.internetDataUsageRate = internetDataUsageRate;
			}

			public String getPlanCircle() {
				return planCircle;
			}

			public void setPlanCircle(String planCircle) {
				this.planCircle = planCircle;
			}

			public String getPlanName() {
				return planName;
			}

			public void setPlanName(String planName) {
				this.planName = planName;
			}
			 
}
