package com.cg.mobilebilling.main;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
public class MainClass {
	public static void main(String[] args) {
	Plan p1=new Plan(21,22,23,24,8,5,6,4,3,2,1,9,"hyd","less");
	System.out.println(p1.getPlanCircle());			
	System.out.println(p1.getLocalCallRate());
	Customer c1=new Customer(2201,9440564669l,"preethi","bvs","te@t","11-9-1995","en2","45g");
	System.out.println(c1.getFirstname());
	System.out.println(c1.getMobileNo());
	System.out.println(c1.getDateOfbirth());
	}
}
