package com.cg.banking.beans;
public class Customer {
	private int customerId,mobileNo;
	private String firstName,lastName,dateOfBirth,
				emailId,adharno,pancardNo;
	private Address localaddress,homeaddress;
	private Account[] accounts;
	public Customer() {}
	public Customer(int customerId, int mobileNo, String firstName, String lastName, String dateOfBirth, String emailId,
			String adharno, String pancardNo,Address localaddress,Address homeaddress,Account[] accounts) {
		super();
		this.customerId = customerId;
		this.mobileNo = mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.emailId = emailId;
		this.adharno = adharno;
		this.pancardNo = pancardNo;
		this.localaddress = localaddress;
		this.homeaddress = homeaddress;
		this.accounts = accounts;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAdharno() {
		return adharno;
	}
	public void setAdharno(String adharno) {
		this.adharno = adharno;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public Address getLocaladdress() {
		return localaddress;
	}
	public void setLocaladdress(Address localaddress) {
		this.localaddress = localaddress;
	}
	public Address getHomeaddress() {
		return homeaddress;
	}
	public void setHomeaddress(Address homeaddress) {
		this.homeaddress = homeaddress;
	}
	public Account[] getAccount() {
		return accounts;
	}
	public void setAccount(Account[] accounts) {
		this.accounts = accounts;
	}
}	