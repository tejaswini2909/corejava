package com.cg.inheritance.beans;
public class Salesmanager extends PEmployee {
	private double commision,salesAmount;
	public Salesmanager() {
		super();
	}
	
	public Salesmanager(int employeeId, int basicSalary, String firstName, String lastName, double hra, double ta,
			double da, double salesAmount) {
		super(employeeId, basicSalary, firstName, lastName, hra, ta, da);
		this.salesAmount = salesAmount;
	}

	public double getCommision() {
		return commision;
	}

	public void setCommision(double commision) {
		this.commision = commision;
	}

	public double getSalesAmount() {
		return salesAmount;
	}

	public void setSalesAmount(double salesAmount) {
		this.salesAmount = salesAmount;
	}

	public final void calculateSalary() {
		super.calculateSalary();
		this.commision=(int)((0.1)*(this.getSalesAmount()));
		this.setTotalSal(this.getTotalSal()+this.commision);
	}	
	public String toString() {
	return super.toString()+"Commision="+commision;
    }
}
