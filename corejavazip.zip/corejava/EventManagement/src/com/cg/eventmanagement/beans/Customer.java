package com.cg.eventmanagement.beans;
public class Customer {
		private String name;
		private long mobileNo;
		private Event[] events;
		private Customer() {}
		public Customer(String name, long mobileNo, Event[] events) {
			super();
			this.name = name;
			this.mobileNo = mobileNo;
			this.events = events;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public long getMobileNo() {
			return mobileNo;
		}
		public void setMobileNo(long mobileNo) {
			this.mobileNo = mobileNo;
		}
		public Event[] getEvents() {
			return events;
		}
		public void setEvents(Event[] events) {
			this.events = events;
		}
}
			